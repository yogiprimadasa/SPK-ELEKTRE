 <?php
 echo"<script>alert('Data Berhasil di Proses');window.location.href='index.php?menu=lihat_hasil'</script>"; ?>