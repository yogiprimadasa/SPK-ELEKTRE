<div id="footer">
        <p>&copy;  <?php echo date("Y");?> All Right Reserved </p>
</div>