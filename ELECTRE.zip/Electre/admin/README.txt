Hai
Selamat Datang di SIRS
Untuk cara instll : 
1) Buat Folder di htdocs atau www dengan nama gd_sirs atau langsung ekstrak ke direktori Anda
2) Lalu buka phpmyadmin, kemudian buat database bernama gd_sirs
3) Import database di folder db->gd_sirs.sql
4) Happy Enjoy...


by   : Maful P Arnandi
blog : http://mafulprayogaarnandi.blogspot.com/
web  : http://bocahdesa.com/

{keep}coding
