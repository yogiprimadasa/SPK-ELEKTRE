<style type="text/css">
<!--
.style1 {font-size: 16px}
-->
</style>
<div class="container">
  <div class="inside">
    <div class="wrapper">
      <aside>
        <h2>Our <span>Contacts</span></h2>
        <ul class="contacts">
          
          <li><span class="style1"><strong>Telephone : </strong>082170214495</span></li><br>
         
          <li class="style1"><strong>Email  : </strong><a href="#">banaswalayan@gmail.com</a></li><br>
		   <li class="style1"><strong>Alamat:</strong> Padang</a></li>
        </ul>
        
      </aside>
      <section id="content">
        <article>
          <h2>&nbsp;</h2>
        </article>
      </section>
    </div>
  </div>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br>