<style type="text/css">
.wrap {
	overflow:hidden;
	position:relative
}
.block-1>div {
	float:left;
	width:180px;
	margin-right:40px;
}
.block-1>div h3 {
	margin:14px 0 4px 0;
}
.block-1>div a.button {
	margin:18px 0 0px 0;
}
a.button {
	background:#2098f5;
	font-size:20px;
	line-height:24px;
	color:#fff;
	display:inline-block;
	padding:5px 23px 5px 23px;
}
.last {
	margin-right:0px !important;
}

.style1 {font-family: "Comic Sans MS"}
.style2 {
	color: #000000;
	font-size: 17px;
	font-family: "Trebuchet MS";
}
</style>

<span class="style1">Welcome to Sistem Pendukung Keputusan </span>
<hr>
<div align="justify" class="style2">Sistem Pendukung Keputusan (SPK) atau Decision Support System (DSS) adalah sebuah sistem yang mampu memberikan kemampuan pemecahan masalah maupun kemampuan pengkomunikasian untuk masalah dengan kondisi semi terstruktur dan tak terstruktur. Sistem ini digunakan untuk membantu pengambilan keputusan dalam situasi semi terstruktur dan situasi yang tidak terstruktur, dimana tak seorangpun tahu secara pasti bagaimana keputusan seharusnya dibuat (Turban, 2001).
  
  SPK bertujuan untuk menyediakan informasi, membimbing, memberikan prediksi serta mengarahkan kepada pengguna informasi agar dapat melakukan pengambilan keputusan dengan lebih baik.
  <br><br>
  SPK merupakan implementasi teori-teori pengambilan keputusan yang telah diperkenalkan oleh ilmu-ilmu seperti operation research dan menegement science, hanya bedanya adalah bahwa jika dahulu untuk mencari penyelesaian masalah yang dihadapi harus dilakukan perhitungan iterasi secara manual (biasanya untuk mencari nilai minimum, maksimum, atau optimum), saat ini computer PC telah menawarkan kemampuannya untuk menyelesaikan persoalan yang sama dalam waktu relatif singkat.</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>