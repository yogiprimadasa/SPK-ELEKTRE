<?php
	$server = mysql_connect("localhost","budi","1");
	$db = mysql_select_db("budi_electre");
	
	if(!$server){
		echo "Maaf, Gagal tersambung dengan server !";
	}
	if(!$db){
		echo "Maaf, Gagal tersambung dengan database !";
	}
?>