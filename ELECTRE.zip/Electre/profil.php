<style type="text/css">
.wrap {
	overflow:hidden;
	position:relative
}
.block-1>div {
	float:left;
	width:180px;
	margin-right:40px;
}
.block-1>div h3 {
	margin:14px 0 4px 0;
}
.block-1>div a.button {
	margin:18px 0 0px 0;
}
a.button {
	background:#2098f5;
	font-size:20px;
	line-height:24px;
	color:#fff;
	display:inline-block;
	padding:5px 23px 5px 23px;
}
.last {
	margin-right:0px !important;
}

.style1 {font-family: "Comic Sans MS"}
</style>

<article>
            <h2>Bana Swalayan </h2>
            <p>Bana Swalayan  merupakan usaha dagang yang bergerak dalam penjualan produk keseharian. Bana Swalayan ini berdiri pada tahun 2014 yang didirikan oleh Bapak Amrizal. Bana Swalayan ini merupakan usaha keluarga. 
              Bana Swalayan ini digerakkan oleh 2 orang yaitu Bapak Amrizal dan Ibu Ismawati. </p>
            <br />
Adapun visi dan misi yang ingin dicapai oleh Bana Swalayan adalah:<br />
<br />
1. Visi<br />
a.	Memberikan yang terbaik dalam pelayanan dan kenyamanan pelanggan.<br />
b.	Memberikan jasa pelayanan barang yang terbaik bagi pelanggan.<br />
c.	Mengutamakan kepuasan pelanggan.<br />
<br />
2. Misi<br />
a.	Menyediakan sarana dan prasarana yang berkualitas. <br />
b.	Memberikan pelayanan yang cepat, akurat dan terpercaya dengan biaya terjangkau. <br />
<p class="style1">&nbsp;</p>
            